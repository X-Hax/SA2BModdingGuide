Welcome to your own "My Level Mod!"

This mod was built to make creating and importing maps
into Sonic Adventure 2 Battle quicker and easier. 

If you ever need any assistance please join the X-Hax
discord at https://discord.gg/gqJCF47

HOW TO USE:
Simply drop your "level.sa2blvl" and "texture.pak" level here, and run the mod twice! That will move your files into the right location, and finalize your mod.

This tool was built for the "How to create your own Sonic Adventure 2
level" tutorial. You can find that here:
https://github.com/X-Hax/SA2BModdingGuide/wiki/Level-Modding-Tutorial

LEVEL_OPTIONS.ini:
Use this file to configure different aspects of your level.
Currently supported options:

Start: x, y, z coodinates (Sets Sonic's start location)
End: x, y, z coordinates (Set's Sonic's end location (NOT GOAL RING))
Level: 2 digit level id (See the level modding tutorial for level ids (13 for city escape))

NOTES:
By default, this level replaces City Escape. To play your level,
simply load up City Escape ingame. If you would like to add additional features such as your own enemies, add in/replace the necessary files in the gd_PC folder. (set files are for enemies)