Welcome to your own "My Level Mod!"

This mod was built to make creating and importing maps
into Sonic Adventure 2 Battle quicker and easier. 

If you ever need any assistance please join the X-Hax
discord at https://discord.gg/gqJCF47

HOW TO USE:
Simply drop your "level.sa2blvl" and "texture.pak" level here, and run the mod twice! That will move your files into the right location, and load up your mod. Otherwise, follow the instructions below:

Simply create a level following the tutorial here: (LINK WIP)
Then, once you're finished, drop your lvl file in the "gd_PC"
folder and rename it to "level.sa2blvl". For your textures,
drop your PAK file into the "PRS" folder in the "gd_PC"
folder, and rename it to "texture".

Also, to include a start and end location for your level, please
input that in the gd_PC/leveloptions file. More customization coming
soon!

NOTES:
By default, this level replaces City Escape. To play your level,
simply load up City Escape ingame. Also, the way it works is
that files in the gd_PC folder will replace existing game files,
so if you would like to add your own custom SET file for enemies
and objects, feel free to replace the set files with your own.